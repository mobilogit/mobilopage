# Demo Flask App (CC-GitActions)
## Purpose
- commit code to development
- run action
  - build
  - test
  - deploy to Azure dev appliacation
- pull request to production
  - run action
    - build
    - deploy to Azure prd application   
